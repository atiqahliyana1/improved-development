# CloudCom
This represents the inside of 'src' directory for a ROS workspace.

It contains the following packages developed for the UGV project:

 - ugv_database
 - lora_py

Additionally, the following package(s) are required as dependency/ies:

 - rospy_message_converter
