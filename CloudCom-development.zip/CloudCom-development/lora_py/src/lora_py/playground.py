# m300h module

# from m300h import *

# print(REPORT)
# print(AT_CMD_PREFIX, GET_STR, CRLF, SET_STR, sep="")
# print(AT_CMD_PREFIX, AT_COMMANDS["LRSEND"])
# print("DUTYCYCLEEN" in AT_COMMANDS.keys())
# print(AT_COMMANDS['LRSEND'][:2])
# print(repr(StatusNetwork.RESET))
# print(StatusMsg[StatusNetwork.P2P_NETWORK])
# print(CommandNotFoundError)

# commands module

from commands import *

"""
A node to fetch all UGV data and uplink depending on set Rate?
"""