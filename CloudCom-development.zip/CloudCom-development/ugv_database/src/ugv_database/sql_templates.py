INSERT = "INSERT INTO {} VALUES (nextval('{}_id_seq')"
INSERT_VARIABLE = ", %s"
INSERT_END = ")"

SELECT_ALL = "SELECT * FROM {}"

UPDATE = "UPDATE {} SET {} = %s"
UPDATE_VARIABLE = ", {} = %s"
UPDATE_END = " WHERE id = %s"