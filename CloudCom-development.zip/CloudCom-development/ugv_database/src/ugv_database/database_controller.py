"""
@author: Ali Madani
@email: ali_m_m_m@outlook.com
"""

from ugv_database.sql_templates import *
import psycopg2

class DatabaseController():

    _database = None
    
    def __init__(self, database, user, password):
        try:        
            self._database = psycopg2.connect(
                database=database,
                user=user,
                password=password
            )
            print("Connected to database.")
        except Exception as e:
            print("Failed to connect to database.")
            print(e)

    def __del__(self):
        try:
            if self._database:
                self._database.close()
            print("Database connection closed.")
        except Exception as e:
            print("Failed to terminate database connection.")
            print(e)

    def _create_cursor(self): # ?
        cursor = self._database.cursor()
        print("Cursor created.")
        return cursor

    def _delete_cursor(self, cursor):
        if not cursor.closed:
            cursor.close()
            print("Cursor closed.")
        else:
            print("Cursor already closed.")
        

    def _construct_insert_sql_statement(self, table, variables_count):
        return INSERT.format(table, table) + variables_count * INSERT_VARIABLE + INSERT_END
    
    def _construct_update_sql_statement(self, table, columns):
        column_count = len(columns)
        update_statment = UPDATE
        update_statment += (column_count - 1) * UPDATE_VARIABLE if column_count > 1 else ''
        update_statment += UPDATE_END
        return update_statment.format(table, *columns)

    def _construct_fetch_result_objects(self, cursor, data):
        columns = [desc[0] for desc in cursor.description]
        data_objects = []
        for row in data:
            result_object = {}
            for index, column in enumerate(columns):
                if column not in ['timestamp', 'active']:
                    result_object[column] = str(row[index])
            data_objects.append(result_object)
        return data_objects
        
    def insert_data(self, table, data):
        # May need to ensure that data is arranged properly
        cursor = self._create_cursor()
        variables = data.values()
        cursor.execute(
            self._construct_insert_sql_statement(table, len(variables)),
            [*variables]
        )
        self._database.commit()
        print("Data inserted successfully.")
        self._delete_cursor(cursor)

    def fetch_data(self, table):
        cursor = self._create_cursor()
        cursor.execute(SELECT_ALL.format(table))
        result = cursor.fetchall()
        result = self._construct_fetch_result_objects(cursor, result)
        self._delete_cursor(cursor)
        return result
    
    def update_data(self, table, data, id):
        cursor = self._create_cursor()
        cursor.execute(
            self._construct_update_sql_statement(table, [*data.keys()]),
            [*data.values(), id]
        )
        self._database.commit()
        print("Data updated successfully.")
        self._delete_cursor(cursor)
