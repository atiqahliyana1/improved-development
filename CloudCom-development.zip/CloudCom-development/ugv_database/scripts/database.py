import rospy
from rospy_message_converter import message_converter
from ugv_database.database_controller import DatabaseController
import ugv_database.msg as ros_message
import ugv_database.srv as ros_service

def insert_callback(data, table):
    # TOPIC HANDLER
    rospy.loginfo("Inserting data into " + table + " table...")
    db.insert_data(
        table,
        message_converter.convert_ros_message_to_dictionary(data)
    )

def fetch_callback(request, tables):
    # SERVICE HANDLER
    table = next(item for item in tables if item['service_request'] == request.__class__)
    rospy.loginfo("Fetching data from " + table['name'] + " table...")
    ros_result = []
    result = db.fetch_data(table['name'])
    for row in result:
        ros_result.append(
            message_converter.convert_dictionary_to_ros_message('ugv_database/' + table['service'].__name__ + '_Unit', row, kind='message')
        )
    return table['service_response'](ros_result)

def fetch_all_tables():
    tables = []
    cursor = db._create_cursor()
    rospy.loginfo("Fetching tables...")
    cursor.execute("SELECT DISTINCT table_name FROM information_schema.columns WHERE (table_schema = 'public' AND table_name NOT LIKE 'config_%');")
    result = cursor.fetchall()
    for item in result:
        tables.append({
            "name": item[0]
            })
    db._delete_cursor(cursor)
    return tables

def construct_message_names(tables):
    rospy.loginfo("Fetching message and service files...")
    for table in tables:
        message = "".join([part.capitalize() for part in table['name'].split("_")])
        table['message'] = getattr(
            ros_message,
            message,
            None
        )
        table['service'] = getattr(
            ros_service,
            message + "_F",
            None
        )
        table['service_request'] = getattr(
            ros_service,
            message + "_FRequest",
            None
        )
        table['service_response'] = getattr(
            ros_service,
            message + "_FResponse",
            None
        )
    return tables

def initialize():
    rospy.init_node("database", anonymous=True)
    rospy.loginfo("Launching database node...")
    tables = construct_message_names(fetch_all_tables())
    # tables_global = tables.copy()
    for table in tables:
        topic = 'database/' + table['name']
        if table['message'] != None:
            rospy.Subscriber(topic, table['message'], insert_callback, table['name'])
            rospy.loginfo(topic + " - Subscribed to topic")
        else:
            rospy.loginfo(topic + " - Omitted topic (No .msg file)")
        if table['service'] != None:     
            rospy.Service(
                topic, 
                table['service'], 
                lambda request: fetch_callback(request, tables)
            )
            rospy.loginfo(topic + " - Service active")
        else:
            rospy.loginfo(topic + " - Service omitted (No .srv file)")
    rospy.loginfo("Use topics for data insertion and services for data fetch.")
    rospy.spin()

if __name__ == '__main__':
    db = DatabaseController(
        database="ugv",
        user="ugv",
        password="Meraque1234"
    )
    initialize()

# SELECT table_name, column_name, data_type FROM information_schema.columns WHERE (table_schema = 'public' AND table_name NOT LIKE 'config_%');
