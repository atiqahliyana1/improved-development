"""
@author: Ali Madani
@email: ali_m_m_m@outlook.com
"""

from sql_templates import *
import psycopg2

class DatabaseController():

    _database = None
    
    def __init__(self, database, user, password):
        try:        
            self._database = psycopg2.connect(
                database=database,
                user=user,
                password=password
            )
            print("Connected to database.")
        except Exception as e:
            print("Failed to connect to database.")
            print(e)

    def __del__(self):
        try:
            if self._database:
                self._database.close()
            print("Database connection closed.")
        except Exception as e:
            print("Failed to terminate database connection.")
            print(e)

    def _create_cursor(self): # ?
        cursor = self._database.cursor()
        print("Cursor created.")
        return cursor

    def _delete_cursor(self, cursor):
        if not cursor.closed:
            cursor.close()
            print("Cursor closed.")
        else:
            print("Cursor already closed.")
        

    def _construct_insert_sql_statement(self, table, variables_count):
        return INSERT.format(table, table) + variables_count * INSERT_VARIABLE + INSERT_END
    
    def _construct_update_sql_statement(self, table, columns):
        column_count = len(columns)
        update_statment = UPDATE
        update_statment += (column_count - 1) * UPDATE_VARIABLE if column_count > 1 else ''
        update_statment += UPDATE_END
        return update_statment.format(table, *columns)
        
    def insert_data(self, table, data):
        # May need to ensure that data is arranged properly
        cursor = self._create_cursor()
        variables = data.values()
        cursor.execute(
            self._construct_insert_sql_statement(table, len(variables)),
            [*variables]
        )
        self._database.commit()
        print("Data inserted successfully.")
        self._delete_cursor(cursor)

    def fetch_data(self, table):
        cursor = self._create_cursor()
        cursor.execute(SELECT_ALL.format(table))
        result = cursor.fetchall()
        self._delete_cursor(cursor)
        return result
    
    def update_data(self, table, data, id):
        cursor = self._create_cursor()
        cursor.execute(
            self._construct_update_sql_statement(table, [*data.keys()]),
            [*data.values(), id]
        )
        self._database.commit()
        print("Data updated successfully.")
        self._delete_cursor(cursor)


# test_data_insert = {'cloud_id': '619', 'latitude': '1.234567890', 'longitude': '987.654321000', 'altitude': '0.000000000', 'initial': '0', 'bearing': '0.000000000', 'task_id': '1'}
# test_columns = ['latitude', 'longitude', 'bearing']
# test_data_update = {'latitude': '1.231231231', 'longitude': '456.456456456', 'bearing': '1.000000000'}
# lis = test_data.values()
# x = [*lis]
# x = (y for y in lis)
# print(x)
# print(len(lis))
# sql = DatabaseController._construct_insert_sql_statement(DatabaseController, "gis_dump", 7)
# sql = sql.replace("%s", "{}")
# sql = sql.format(*lis)
# print(sql)

# con = DatabaseController(
#     "ugv", "ugv", "Meraque1234"
# )
# x = con.fetch_data("gis_dump")
# print(x)
# for y in x:
#     print(repr(y))
# print(DatabaseController._construct_update_sql_statement(DatabaseController, "gis_dump", test_columns))
# con.update_data("gis_dump", test_data_update, 39)